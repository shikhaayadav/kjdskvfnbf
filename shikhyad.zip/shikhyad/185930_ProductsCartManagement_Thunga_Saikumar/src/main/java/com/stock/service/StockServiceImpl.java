package com.stock.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stock.bean.Stock;
import com.stock.dao.IStockRepo;
import com.stock.exception.StockException;

@Service
public class StockServiceImpl implements StockService {

	@Autowired
	IStockRepo stockRepo;
	
	// Method to add the stock in the database
	@Override
	public List<Stock> createStock(Stock stock) throws StockException {
		try {
			double amount = stock.getPrice()*stock.getQuantity();
			stock.setAmount(amount);
			if(stock.getQuantity()<=100)
				stock.setBrokerage((amount*0.5)/100);
			else
				stock.setBrokerage((amount*0.3)/100);
			stockRepo.saveAndFlush(stock);
			return stockRepo.findAll();
		}
		catch (Exception e) {
			throw new StockException(e.getMessage());
		}
		     
	}
	
	// Method to update the existing stock in the database
	public List<Stock> updateStock(int id, Stock stock)  throws StockException{
		try {
			Optional<Stock> optional = stockRepo.findById(id);
			if(optional.isPresent())
			{
				Stock stockObj = optional.get();
				stockObj.setName(stock.getName());
				stockObj.setPrice(stock.getPrice());
				stockObj.setQuantity(stock.getQuantity());
				stockRepo.save(stockObj);
				return viewAllStock();
			}
			else
			{
				throw new StockException("Stock with Id "+id+" is not  existing please enter a valid id ");	
			}
			
		}
		catch (Exception e) {
			throw new StockException(e.getMessage());
		}
	}
	
	
	// Method to delete the stock whoes stock id is given
	@Override
	public void deleteStock(int id) throws StockException{
		try {
			stockRepo.deleteById(id);
		}
		catch (Exception e) {
			throw new StockException(e.getMessage());
		}
	}
	
	
	// Method to view all the details of stock
	@Override
	public List<Stock> viewAllStock() throws StockException{
		try {
			return stockRepo.findAll();
		}
		catch (Exception e) {
			throw new StockException(e.getMessage());
		}
	}
	
	
	// Method to retrieve the detail of the stock for given id
	@Override
	public Stock findSingleStock(int id) throws StockException{ 
		try{
			return stockRepo.findById(id).get();
		}
		catch (Exception e) {
			throw new StockException(e.getMessage());
		}
	}
	 
}
