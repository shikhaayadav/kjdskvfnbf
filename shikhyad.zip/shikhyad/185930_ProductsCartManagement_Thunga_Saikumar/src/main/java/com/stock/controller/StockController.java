package com.stock.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.stock.bean.Stock;
import com.stock.exception.StockException;
import com.stock.service.StockService;

@RestController
public class StockController {

	@Autowired
	StockService stockServiceObj;
	
	
	// Method to call the create method of serviceImpl
	@RequestMapping(value="/stock", method=RequestMethod.POST)
	public List<Stock> createStock(@RequestBody Stock stock) throws StockException{
		return stockServiceObj.createStock(stock);
	}
	
	// Method to call the update method of serviceImpl
	@PutMapping("/stock/{id}")
	public List <Stock> updateStock(@PathVariable int id, @RequestBody Stock stock) throws StockException{
		return stockServiceObj.updateStock(id, stock);
	}
	
	// Method to call the delete method of serviceImpl
	@DeleteMapping("/stocks/{id}")	
	public ResponseEntity<String> deleteStock(@PathVariable int id) throws StockException{
		stockServiceObj.deleteStock(id);
		return new ResponseEntity<String> ("Product with id "+id+" deleted successfullyy",HttpStatus.OK);
	}
	
	// Method to call viewAllMethod method of serviceImpl
	@RequestMapping("/stocks")
	public List <Stock> viewAllStock() throws StockException{
		return stockServiceObj.viewAllStock();
	}
	
	
	// Method to call the findSingleStock method of serviceImpl
	@RequestMapping("/stocksingle/{id}")
	public Stock findSingleStock(@PathVariable int id) throws StockException{
		return stockServiceObj.findSingleStock(id);
    }
	
	
	
}
