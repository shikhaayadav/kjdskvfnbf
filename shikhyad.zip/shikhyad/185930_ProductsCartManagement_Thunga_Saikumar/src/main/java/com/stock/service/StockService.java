package com.stock.service;

import java.util.List;

import com.stock.bean.Stock;
import com.stock.exception.StockException;

public interface StockService {

	
	public List<Stock> createStock(Stock stock) throws StockException;
	public List<Stock> updateStock(int id, Stock stock) throws StockException;
	public void deleteStock (int id) throws StockException;
	public List<Stock> viewAllStock() throws StockException;
	public Stock findSingleStock(int id) throws StockException;
	
}
