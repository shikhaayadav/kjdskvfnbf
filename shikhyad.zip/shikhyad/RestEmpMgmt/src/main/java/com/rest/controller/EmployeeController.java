package com.rest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.rest.exceptions.EmployeesNotFoundException;
import com.rest.exceptions.NoSuchEmployeeException;
import com.rest.model.Employee;
import com.rest.service.EmployeeService;

@RestController
public class EmployeeController {
	@Autowired
	EmployeeService service;
	
	
	 
	
	@PostMapping(value="/employees")
	public ResponseEntity<String> addEmployee(@RequestBody Employee emp) {
		
		
		String response = service.insertEmployee(emp);
		//return new ResponseEntity<String>(response, HttpStatus.OK);
		return ResponseEntity.ok(response);
	}
	@GetMapping(value="/employees")
	public ResponseEntity<List<Employee>> getEmployees() throws EmployeesNotFoundException{ 
		List<Employee> empList= service.getEmployoees();
		return ResponseEntity.ok(empList);
	}
	@GetMapping(value="/employees/{empId}")
	public ResponseEntity<Employee> getEmployee(@PathVariable("empId") int empId) throws NoSuchEmployeeException{ 
		Employee emp= service.findEmployee(empId);
		return ResponseEntity.ok(emp);
	}
	
		@PutMapping(value = "/employees/{empId}")
		public String updateEmployee(@PathVariable("empId") int empId, @RequestBody Employee employee) throws NoSuchEmployeeException{
			return service.updateEmployee(empId, employee);
		}
		
		@DeleteMapping(value = "/employees/{empId}")
		public String deleteCustomer(@PathVariable("empId") int empId) throws NoSuchEmployeeException {
			return service.removeEmployee(empId);
		}
	
}
