package com.cg.client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;
import com.cg.entities.Book;
import com.cg.service.BookAuthorServiceImpl;

public class Starter {

	public static void main(String args[]) throws IOException {
		BookAuthorServiceImpl service = new BookAuthorServiceImpl();
		List<Book> bookList;
		List<String> list;
		String choice;
		String authorName;
		double minRange, maxRange;
		boolean ch = true;
		do {
		
			System.out.println("Enter choice");
			System.out.println("1. Get all the books");
			System.out.println("2. Get books by author");
			System.out.println("3. Get books by price range");
			System.out.println("4. Get author name");
			System.out.println("5. Exit");
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			choice=br.readLine();
			switch(choice) {
			
			case "1": 
						bookList=service.getAllBooks();
						for(Book b: bookList)
							System.out.println(b.getBookIsbn()+"\t"+b.getPrice()+"\t"+b.getTitle());
						break;
			
			case "2": 
						System.out.println("Enter the author name");
						authorName=br.readLine();
						bookList=service.getBooksByAuthor(authorName);
						for(Book b: bookList)
							System.out.println(b.getTitle());
						break;
						
			case "3": 
						System.out.println("Enter the price range");
						minRange=Double.parseDouble(br.readLine());
						maxRange=Double.parseDouble(br.readLine());
						bookList=service.getBooksByPriceRange(minRange, maxRange);
						for(Book b: bookList)
							System.out.println(b.getBookIsbn()+"\t"+b.getPrice()+"\t"+b.getTitle());
						break;
						
			case "4": 	
						System.out.println("Enter the book id");
						list=service.getAuthorName(Long.parseLong(br.readLine()));
						for(String s: list)
							System.out.println(s);
						break;
						
			case "5":   
						ch=false;
						break;

			default:    
						System.out.println("Enter Valid Choice");
			}
			
			
		}while(ch);
			
	}

}
