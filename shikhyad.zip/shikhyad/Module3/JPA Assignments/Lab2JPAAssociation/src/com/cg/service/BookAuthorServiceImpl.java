package com.cg.service;

import java.util.List;

import com.cg.dao.BookAuthorDAOImpl;
import com.cg.entities.Book;

public class BookAuthorServiceImpl implements BookAuthorService {

	BookAuthorDAOImpl dao= new BookAuthorDAOImpl();
	@Override
	public List<Book> getAllBooks() {
		return dao.getAllBooks();
	}

	@Override
	public List<Book> getBooksByAuthor(String authorName) {
		return dao.getBooksByAuthor(authorName);
	}

	@Override
	public List<Book> getBooksByPriceRange(double min, double max) {
		if(min>=0&&max>0&&min<max)
			return dao.getBooksByPriceRange(min, max);
		else
			return null;
	}

	@Override
	public List<String> getAuthorName(long bookId) {
		if(bookId>0)
			return dao.getAuthorName(bookId);
		else
			return null;
	}

}
