package com.cg.jpa.ui;

import java.util.Scanner;

import com.cg.jpa.bean.Author;
import com.cg.jpa.service.AuthorService;

public class Starter {

	public static void main(String[] args) {
		
		Author author = new Author();
		AuthorService serObj = new AuthorService();
		Scanner sc = new Scanner(System.in);
		boolean value = true;
		do {
			System.out.println("1. Add");
			System.out.println("2. Update");
			System.out.println("3. Delete");
			System.out.println("4. Retrieve");
			System.out.println("5. Exit");
			String choice = sc.next();
			int id = 0;
			boolean res = false;
			switch(choice) {
				
				case "1":
					System.out.println("Enter author id : ");
					int authorId = sc.nextInt();
					System.out.println("Enter author first name : ");
					String firstName = sc.next();
					System.out.println("Enter author middle name : ");
					String middleName = sc.next();
					System.out.println("Enter author last name : ");
					String lastName = sc.next();
					System.out.println("Enter phone number : ");
					long phoneNo = sc.nextLong();
					author.setAuthorId(authorId);
					author.setFirstName(firstName);
					author.setMiddleName(middleName);
					author.setLastName(lastName);
					author.setPhoneNo(phoneNo);
					serObj.add(author);
					System.out.println("Data inserted successfully");
					break;
				
				case "2":
					System.out.println("Enter author id");
					id = sc.nextInt();
					System.out.println("Enter the new mobile number");
					long phone = sc.nextLong();
					res = serObj.update(id, phone);
					if(res)
						System.out.println("Update mobile number successfully");
					break;
				
				case "3":
					System.out.println("Enter author id");
					id = sc.nextInt();
					res = serObj.delete(id);
					if(res)
						System.out.println("Delete row successfully");
					break;
				
				case "4":
					System.out.println("Enter author id");
					id = sc.nextInt();
					author = serObj.retrieve(id);
					System.out.println("Author Id is : "+author.getAuthorId());
					System.out.println("Author Name is : "+author.getFirstName()+" "+author.getMiddleName()+" "+author.getLastName());
					System.out.println("Author phone number is : "+ author.getPhoneNo());
					break;
				
				case "5":
					value=false;
			}
		}while(value);
		sc.close();
	}
	
}
