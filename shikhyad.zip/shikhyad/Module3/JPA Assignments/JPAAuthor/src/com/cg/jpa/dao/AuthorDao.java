package com.cg.jpa.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import com.cg.jpa.bean.Author;

public class AuthorDao {

	EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPAAuthor");
	EntityManager em = emf.createEntityManager();
	
	public void add(Author author) {
		em.getTransaction().begin();
		em.persist(author);
		em.getTransaction().commit();
	}
	
	public boolean update(int id, long no) {
		Author author = em.find(Author.class, id);
		if(author!=null) {
			em.getTransaction().begin();
			author.setPhoneNo(no);
			em.getTransaction().commit();
			return true;
		}
		else
			return false;
	}
	
	public boolean delete(int id) {
		Author author = em.find(Author.class, id);
		if(author!=null) {
			em.getTransaction().begin();
			em.remove(author);
			em.getTransaction().commit();
			return true;
		}
		else
			return false;
	}
	
	public Author retrieve(int id) {
		Author author = em.find(Author.class, id);
		if(author!=null) {
			return author;
		}
		else
			return null;
	}
}
