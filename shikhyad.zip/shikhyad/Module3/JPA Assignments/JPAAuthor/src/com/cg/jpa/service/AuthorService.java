package com.cg.jpa.service;

import com.cg.jpa.bean.Author;
import com.cg.jpa.dao.AuthorDao;

public class AuthorService {

	AuthorDao daoObj = new AuthorDao();
	
	public void add(Author author) {
		daoObj.add(author);
	}
	
	public boolean update(int id, long phone) {
		boolean res = daoObj.update(id, phone);
		return res;
	}
	
	public boolean delete(int id) {
		boolean res = daoObj.delete(id);
		return res;
	}
	
	public Author retrieve(int id) {
		Author res = daoObj.retrieve(id);
		return res;
	}
}
