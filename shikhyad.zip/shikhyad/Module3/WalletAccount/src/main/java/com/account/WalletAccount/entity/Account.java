package com.account.WalletAccount.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="account")
public class Account {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="accno")
	private int accno;
	@Column(name="balance")
	private float balance;
	@Column(name="uname")
	private String fname;
	public Account(){
		super();
		
	}

	
	
	
	
	//GETTER & SETTER STARTS

	
	
	

	public float getBalance() 
	{
		return balance;
	}

	public int getAccNo() {
		return accno;
	}
	public void setAccNo(int accNo) {
		this.accno = accNo;
	}
	public void setBalance(float balance) 
	{
		this.balance = balance;
	}

	public String getFname()
	{
		return fname;
	}

	public void setFname(String name) 
	{
		this.fname = name;
	}





}
