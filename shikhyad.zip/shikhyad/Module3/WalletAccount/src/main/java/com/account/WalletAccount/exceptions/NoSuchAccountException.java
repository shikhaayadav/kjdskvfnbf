package com.account.WalletAccount.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.BAD_GATEWAY)
public class NoSuchAccountException extends Exception {
		
	public NoSuchAccountException() {
		super();
	}
	public NoSuchAccountException(String errors) {
		super(errors);
	}
}
