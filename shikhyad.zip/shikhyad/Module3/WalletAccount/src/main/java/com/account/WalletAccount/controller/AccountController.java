package com.account.WalletAccount.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.account.WalletAccount.entity.Account;
import com.account.WalletAccount.exceptions.NoSuchAccountException;
import com.account.WalletAccount.exceptions.AccountsNotFoundException;
import com.account.WalletAccount.service.AccountService;

@RestController
public class AccountController {
	@Autowired
	AccountService service;
	
	
	 
	
	@PostMapping(value="/addaccount")
	public ResponseEntity<String> createOrder(@RequestBody Account emp) {
		String response = (String) service.insertAccount(emp);
		//return new ResponseEntity<String>(response, HttpStatus.OK);
		return ResponseEntity.ok(response);
	}
	@GetMapping(value="/addaccount")
	public ResponseEntity<List<Account>> getAccounts() throws AccountsNotFoundException{ 
		List<Account> empList= service.getAccount();
		return ResponseEntity.ok(empList);
	}
	@GetMapping(value="/addaccount/{accNo}")
	public ResponseEntity<Account> getaccounts(@PathVariable("accNo") int accNo) throws NoSuchAccountException{ 
		Account emp= service.findAccount(accNo);
		return ResponseEntity.ok(emp);
	}

	
		@PutMapping(value = "/addaccount/{accno}")
		public float depositAccount(@PathVariable("accno") int accno,@RequestBody Account user) throws NoSuchAccountException{
			return service.updateAccount(accno, user);
		}
		@PutMapping(value = "/addaccounts/{accNo}")
		public float withdrawAccount(@PathVariable("accNo") int accNo, @RequestBody Account user) throws NoSuchAccountException{
			return service.WithdrawAccount(accNo, user);
		}

		@PutMapping(value = "/addaccount/{srcno}/{destno}")
		public String transfer(@PathVariable("srcno") int srcno,@PathVariable("destno") int destno,@RequestBody Account user) throws NoSuchAccountException{
			return service.transferAmount(srcno, destno,user);
		}
		
		@DeleteMapping(value = "/addaccount/{accNo}")
		public String deleteaccount(@PathVariable("accNo") int accNo) throws NoSuchAccountException {
			return service.removeAccount(accNo);
		}
	
}
