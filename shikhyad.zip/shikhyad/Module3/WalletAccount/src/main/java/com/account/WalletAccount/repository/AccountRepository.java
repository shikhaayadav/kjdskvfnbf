package com.account.WalletAccount.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.account.WalletAccount.entity.Account;

public interface AccountRepository extends JpaRepository<Account, Integer> {

	
	
	//@Query("select emp from Employee emp where emp.city = ?1")
    //Employee  findByCity(String city); 
}
