package com.capgemini.exception;

@SuppressWarnings("serial")
public class AccountNumberException extends Exception{
	public AccountNumberException(String message) {
		super(message);
	}
}
