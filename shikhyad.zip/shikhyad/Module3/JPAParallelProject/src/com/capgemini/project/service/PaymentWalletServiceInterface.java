package com.capgemini.project.service;

import java.sql.SQLException;
import java.util.ArrayList;

import com.capgemini.exception.AccountNumberException;
import com.capgemini.exception.InsufficientAmountException;
import com.capgemini.exception.InvalidInputDetailException;
import com.capgemini.project.bean.PaymentWalletBean;

public interface PaymentWalletServiceInterface {

	Long createAccount(PaymentWalletBean walletBeanObj) throws InvalidInputDetailException, SQLException;
	Double showBalance(Long accountNumber) throws AccountNumberException, SQLException;
	Boolean deposit(Double depositAmount, Long accountNumber) throws AccountNumberException, SQLException;
	Boolean withdraw(Double withdrawAmount, Long accountNumber) throws AccountNumberException, InsufficientAmountException, SQLException;
	Boolean fundTransfer(Double amount, Long sourceAccNumber, Long receiverAccNumber) throws InsufficientAmountException, AccountNumberException, SQLException;
	ArrayList<String> printTransaction(Long accountNumber) throws AccountNumberException, SQLException;
}
