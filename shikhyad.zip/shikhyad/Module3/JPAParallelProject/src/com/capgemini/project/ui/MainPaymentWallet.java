package com.capgemini.project.ui;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

import com.capgemini.exception.AccountNumberException;
import com.capgemini.exception.InsufficientAmountException;
import com.capgemini.exception.InvalidAmountException;
import com.capgemini.exception.InvalidInputDetailException;
import com.capgemini.project.bean.PaymentWalletBean;
import com.capgemini.project.service.PaymentWalletService;

public class MainPaymentWallet {

	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		String accountNumber;
		PaymentWalletService serviceObj = new PaymentWalletService();
		PaymentWalletBean beanObj = new PaymentWalletBean();
		boolean repeatChoice = true;
		System.out.println("-------------------------------------------------Welcome to our Application.--------------------------------------------");
		System.out.println("**************************************************PAYMENT WALLET SERVICE!!!**********************************************");
		do {
			try {
				
				System.out.println("Please select following options");
				System.out.println("Press 1.    Create Account");
				System.out.println("Press 2.    Show Balance");
				System.out.println("Press 3.    Deposit");
				System.out.println("Press 4.    Withdraw");
				System.out.println("Press 5.    Fund Transfer");
				System.out.println("Press 6.    Print Transaction");
				System.out.println("Press 7.    Exit");
				String choice = sc.next();
				sc.nextLine();
				Boolean result = false;
				switch(choice) {
					case "1":
						System.out.println("Enter your Name: ");
						String name = sc.nextLine();
						System.out.println("Enter your Email-Id: ");
						String emailId = sc.next();
						System.out.println("Enter your Mobile Number: ");
						String mobileNumber = sc.next();
						beanObj.setName(name);
						beanObj.setEmailId(emailId);
						beanObj.setMobileNumber(mobileNumber);
						beanObj.setBalance(1000.0);
						accountNumber = String.valueOf(serviceObj.createAccount(beanObj));
						if(accountNumber!=null) {
							System.out.println("********************CONGRATULATIONS "+beanObj.getName()+"!!! Your Account has been created successfully wih initial balance Rs.1000***************************");
							System.out.println("Your Account Number is: "+accountNumber);
						}
						break;
					
					case "2":
						System.out.println("Enter your Account Number");
						accountNumber = sc.next();
						if(serviceObj.accNoCheck(accountNumber)) {
							Double balance = serviceObj.showBalance(Long.parseLong(accountNumber));
							if(balance!=null)
								System.out.println("Your current balance is : "+balance);
						}
						else
							throw new InvalidInputDetailException("Enter valid input");
						break;
					
					case "3":
						System.out.println("Enter your Account Number");
						accountNumber = sc.next();
						if(serviceObj.accNoCheck(accountNumber)) {
							System.out.println("Enter the amount you want to deposit :");
							Double depositAmount = sc.nextDouble();
							if(depositAmount<=0)
								throw new InvalidAmountException("Amount should be greater than 0.");
							result = serviceObj.deposit(depositAmount, Long.parseLong(accountNumber));
							if(result) {
								System.out.println("Deposit Successfully");
							}
						}
						else
							throw new InvalidInputDetailException("Enter valid input");
						break;
						
					case "4":
						System.out.println("Enter your Account Number");
						accountNumber = sc.next();
						if(serviceObj.accNoCheck(accountNumber)) {
							System.out.println("Enter the amount you want to withdraw :");
							Double withdrawAmount = sc.nextDouble();
							if(withdrawAmount<=0)
								throw new InvalidAmountException("Amount should be greater than 0.");
							result = serviceObj.withdraw(withdrawAmount, Long.parseLong(accountNumber));
							if(result)
								System.out.println("Withdraw Successfully");
						}
						else
							throw new InvalidInputDetailException("Enter valid input");
						break;
						
					case "5":
						System.out.println("Enter Source Account Number: ");
							String sourceAccNumber = sc.next();
							System.out.println("Enter Receiver's Account Number: ");
							String receiverAccNumber = sc.next();
							if(serviceObj.accNoCheck(sourceAccNumber) && serviceObj.accNoCheck(receiverAccNumber)) {
								System.out.println("Enter the amount you want to transfer :");
								Double amount = sc.nextDouble();
								if(sourceAccNumber.equals(receiverAccNumber)) {
									System.out.println("You can not transfer money within the same account");
									break;
								}
								if(amount<=0)
									throw new InvalidAmountException("Amount should be greater than 0.");
								result = serviceObj.fundTransfer(amount, Long.parseLong(sourceAccNumber), Long.parseLong(receiverAccNumber));
								if(result)
									System.out.println("Transaction Successfully done");
							}
							else
							throw new InvalidInputDetailException("Enter valid input");	
						break;
						
					case "6":
						System.out.println("Enter your Account Number");
						accountNumber = sc.next();
						if(serviceObj.accNoCheck(accountNumber)) {
							ArrayList<String> arrlist = serviceObj.printTransaction(Long.parseLong(accountNumber));
							if(arrlist!=null) {
								if(arrlist.size()>=1) {
									System.out.println("Hello your recent transactions are: ");
									for(String str: arrlist)
										System.out.println(str);
								}
								else
									System.out.println("You haven't made any transactions yet.");
							}
						}
						else
							throw new InvalidInputDetailException("Enter valid input");
						break;
						
					case "7":
						repeatChoice = false;
						break;
						
					default:
						System.out.println("Please make a valid choice");
					}
			}
			catch (InvalidInputDetailException e) {
				System.out.println(e.getMessage());
			}
			catch (AccountNumberException e) {
				System.out.println(e.getMessage());
			}
			catch (InvalidAmountException e) {
				System.out.println(e.getMessage());
			} 
			catch (InsufficientAmountException e) {
				System.out.println(e.getMessage());
			}
			catch (SQLException e) {
				System.out.println(e.getMessage());
			}
		}while(repeatChoice);
		sc.close();
		System.out.println("Thank you for using our service. ");
	}
}

