package com.capgemini.project.service;

import java.sql.SQLException;
import java.util.ArrayList;

import com.capgemini.exception.AccountNumberException;
import com.capgemini.exception.InvalidInputDetailException;
import com.capgemini.exception.InsufficientAmountException;
import com.capgemini.project.bean.PaymentWalletBean;
import com.capgemini.project.dao.PaymentWalletDao;

public class PaymentWalletService implements PaymentWalletServiceInterface{
	
	PaymentWalletDao walletDaoObj = new PaymentWalletDao();
	Long accNo=null;
	int row=0;
	Boolean result = false;

	public Long createAccount(PaymentWalletBean walletBeanObj) throws InvalidInputDetailException, SQLException{
		if(emailCheck(walletBeanObj.getEmailId()) && numberCheck(walletBeanObj.getMobileNumber()) && nameCheck(walletBeanObj.getName()) && walletBeanObj.getName().length()>=3) {
			accNo = Math.abs((Long.parseLong(walletBeanObj.getMobileNumber())-12341)*13);
			walletBeanObj.setAccountNumber(accNo);
			walletDaoObj.accountCreation(walletBeanObj);
			return accNo;
		} 
		else {
			throw new InvalidInputDetailException("Error Occured!!! Enter valid input");
		}
		
	}
	
	public Double showBalance(Long accountNumber) throws AccountNumberException, SQLException {
		Double balance = walletDaoObj.showBalance(accountNumber);;
		return balance;
	}
	
	public Boolean deposit(Double depositAmount, Long accountNumber) throws AccountNumberException, SQLException {
		return result= walletDaoObj.depositAmt(depositAmount, accountNumber);
	}
	
	public Boolean withdraw(Double withdrawAmount, Long accountNumber) throws AccountNumberException, InsufficientAmountException, SQLException {
		return result = walletDaoObj.withdrawAmt(withdrawAmount, accountNumber);
	}
	
	public Boolean fundTransfer(Double amount, Long sourceAccNumber, Long receiverAccNumber) throws InsufficientAmountException, AccountNumberException, SQLException {
		return result = walletDaoObj.transfer(amount, sourceAccNumber, receiverAccNumber);
		
	}
	
	public ArrayList<String> printTransaction(Long accountNumber) throws AccountNumberException, SQLException {
		ArrayList<String> alist = walletDaoObj.getTransactions(accountNumber);
		if(alist!=null)
			return alist;
		else
			return null;
	}		
	
	boolean nameCheck(String name) {
		boolean result = name.matches("^[a-zA-Z\\s]*$");
		return result;	
	}
	
	boolean emailCheck(String emailId) {
		boolean result = emailId.matches("^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$");
		return result;
	}
	
	boolean numberCheck(String mobile) {
		boolean result = false;
				if(mobile.length()==10 && mobile.charAt(0)!='0')
					result=true;
		return result;
		
	}
	public boolean accNoCheck(String acc) {
		boolean result = false;
		result = acc.matches("[0-9]{9,18}");
		return result;
	}
	
}
