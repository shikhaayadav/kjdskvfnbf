package com.capgemini.project.dao;

import java.sql.SQLException;
import java.util.ArrayList;

import com.capgemini.exception.AccountNumberException;
import com.capgemini.exception.InsufficientAmountException;
import com.capgemini.project.bean.PaymentWalletBean;

public interface PaymentWalletDaoInterface {

	void accountCreation(PaymentWalletBean bean) throws SQLException;
	Double showBalance(Long ano) throws AccountNumberException, SQLException;
	Boolean depositAmt(Double depositAmount, Long accountNumber) throws AccountNumberException, SQLException;
	Boolean withdrawAmt(Double withdrawAmount, Long accountNumber) throws AccountNumberException, InsufficientAmountException, SQLException;
	Boolean transfer(Double amount, Long sourceAccNo, Long receiverAccNo) throws AccountNumberException,InsufficientAmountException, SQLException;
	ArrayList<String> getTransactions(Long accNo) throws AccountNumberException, SQLException;
}
