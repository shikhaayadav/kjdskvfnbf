package com.capgemini.project.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import com.capgemini.exception.AccountNumberException;
import com.capgemini.exception.InsufficientAmountException;
import com.capgemini.project.bean.PaymentWalletBean;


public class PaymentWalletDao implements PaymentWalletDaoInterface {
	
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPAParallelProject");
	EntityManager em = emf.createEntityManager();
	EntityManager em1 = emf.createEntityManager();
	ArrayList<String> alist = new ArrayList<String>();

	public void accountCreation(PaymentWalletBean bean) throws SQLException {
			em.getTransaction().begin();
			em.persist(bean);
			em.getTransaction().commit();
	}
	
	public Double showBalance(Long ano) throws AccountNumberException, SQLException {
		PaymentWalletBean bean = em.find(PaymentWalletBean.class, ano);
		if(bean!=null)
			return bean.getBalance();
		else
			throw new AccountNumberException("Account Number does not exist");
	}
	
	public Boolean depositAmt(Double depositAmount, Long accountNumber) throws AccountNumberException, SQLException {
		PaymentWalletBean bean = em.find(PaymentWalletBean.class, accountNumber);
		if(bean!=null) {
			Double bal  = bean.getBalance();
			em.getTransaction().begin();
			bean.setBalance(bal+depositAmount);
			em.getTransaction().commit();
			alist.add("Rs. "+depositAmount +" deposited in account "+accountNumber);
			return true;
		}
		else
			throw new AccountNumberException("Account Number does not exist");
	}
	
	public Boolean withdrawAmt(Double withdrawAmount, Long accountNumber) throws AccountNumberException, InsufficientAmountException, SQLException {
		PaymentWalletBean bean = em.find(PaymentWalletBean.class, accountNumber);
		if(bean!=null) {
			Double bal  = bean.getBalance();
			if(bal<=withdrawAmount)
				throw new InsufficientAmountException("Amount is not sufficient");
			em.getTransaction().begin();
			bean.setBalance(bal-withdrawAmount);
			em.getTransaction().commit();
			alist.add("Rs. "+withdrawAmount +" withdrawn from account "+accountNumber);
			return true;
		}
		else
			throw new AccountNumberException("Account Number does not exist");
	}
	
	public Boolean transfer(Double amount, Long sourceAccNo, Long receiverAccNo) throws AccountNumberException, InsufficientAmountException, SQLException {
		
		PaymentWalletBean bean = em.find(PaymentWalletBean.class, sourceAccNo);
		if(bean!=null) {
			PaymentWalletBean bean1 = em1.find(PaymentWalletBean.class, receiverAccNo);
			if(bean1!=null) {
				depositAmt(amount, sourceAccNo);
				withdrawAmt(amount, receiverAccNo);
				alist.add("Rs."+amount +" transferred from account "+sourceAccNo+"  to account"+receiverAccNo);
				return true;
			}
			else
				throw new AccountNumberException("Reciever Account Number does not exist");
		}
		else
			throw new AccountNumberException("Source Account Number does not exist");
		
	}
	
	public ArrayList<String> getTransactions(Long accNo) throws AccountNumberException, SQLException {
		PaymentWalletBean bean = em.find(PaymentWalletBean.class, accNo);
		if(bean!=null) {
			return alist;
		}
		else
			throw new AccountNumberException("Source Account Number does not exist");
	
	
	}

}

