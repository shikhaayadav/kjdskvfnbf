package com.capgemini.paymentwallet.dao;

import java.util.ArrayList;
import com.capgemini.exception.InsufficientAmountException;
import com.capgemini.paymentwallet.bean.PaymentWalletBean;

public interface PaymentWalletDaoInterface {

	void accountCreation(PaymentWalletBean bean);
	Double showBalance(Long ano);
	Double depositAmt(Double depositAmount, Long accountNumber);
	Double withdrawAmt(Double withdrawAmount, Long accountNumber) throws InsufficientAmountException;
	Double transfer(Double amount, Long accountNumber, Long receiverAccNumber) throws InsufficientAmountException;
	ArrayList<String> getTransactions(Long accNo);
}
