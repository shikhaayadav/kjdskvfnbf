package com.capgemini.paymentwallet.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Set;
import com.capgemini.exception.InsufficientAmountException;
import com.capgemini.paymentwallet.bean.PaymentWalletBean;

public class PaymentWalletDao implements PaymentWalletDaoInterface {
	
	ArrayList<String> alist= new ArrayList<String>();
	HashMap<Long, PaymentWalletBean> map = new HashMap<Long, PaymentWalletBean>();
	Double result= null;

	public void accountCreation(PaymentWalletBean bean) {
		map.put(bean.getAccountNumber(), bean);
	}
	
	public Double showBalance(Long ano) {
		Set<Entry<Long,PaymentWalletBean>> entryset = map.entrySet();
	
		for(Entry<Long, PaymentWalletBean> entry:entryset) {
			Long acno=entry.getKey();
			if(ano.equals(acno)) {
				PaymentWalletBean bean=entry.getValue();
				result=bean.getBalance();
			}
		} 
		return result;
	}
	
	public Double depositAmt(Double depositAmount, Long accountNumber) {
		Set<Entry<Long,PaymentWalletBean>> entryset = map.entrySet();
		for(Entry<Long, PaymentWalletBean> entry:entryset) {
			Long acno=entry.getKey();
			if(accountNumber.equals(acno)) {
				PaymentWalletBean bean=entry.getValue();
				result=bean.getBalance()+depositAmount;
				bean.setBalance(result);
				alist.add(depositAmount +" deposited in account "+bean.getAccountNumber());
			}
		}
		return result;
	}
	
	public Double withdrawAmt(Double withdrawAmount, Long accountNumber) throws InsufficientAmountException{
		Set<Entry<Long,PaymentWalletBean>> entryset = map.entrySet();	
		for(Entry<Long, PaymentWalletBean> entry:entryset) {
			Long acno=entry.getKey();
				PaymentWalletBean bean=entry.getValue();
				if(accountNumber.equals(acno)) {	
					if(bean.getBalance()<withdrawAmount)
						throw new InsufficientAmountException("Your account balance is not sufficient.");
					result=bean.getBalance()-withdrawAmount;
					bean.setBalance(result);
					alist.add(withdrawAmount +" withdrawn from account "+bean.getAccountNumber());
				}
			}
		return result;
	}
	
	public Double transfer(Double amount, Long accountNumber, Long receiverAccNumber) throws InsufficientAmountException{
		Set<Entry<Long,PaymentWalletBean>> entryset = map.entrySet();	
		for(Entry<Long, PaymentWalletBean> entry:entryset) {
			Long acno1=entry.getKey();
			Long acno2=entry.getKey();
			PaymentWalletBean bean=entry.getValue();
			if(accountNumber.equals(acno1) && receiverAccNumber.equals(acno2)) {	
				if(bean.getBalance()<amount) 
					throw new InsufficientAmountException("Your account balance is not sufficient.");
				result=bean.getBalance()-amount;
				bean.setBalance(result);
				alist.add(amount +" transferred from account "+bean.getAccountNumber());
			}
		}
		return result;
	}
	
	public ArrayList<String> getTransactions(Long accNo) {
		Set<Entry<Long,PaymentWalletBean>> entryset = map.entrySet();	
		for(Entry<Long, PaymentWalletBean> entry:entryset) {
			Long acno=entry.getKey();
				if(accNo.equals(acno))
					return alist;
		}
		return null;
	}
}
