package com.capgemini.paymentwallet.service;

import java.util.ArrayList;

import com.capgemini.exception.AccountExistException;
import com.capgemini.exception.InsufficientAmountException;
import com.capgemini.exception.InvalidInputDetailException;
import com.capgemini.paymentwallet.bean.PaymentWalletBean;

public interface PaymentWalletServiceInterface {

	Long createAccount(PaymentWalletBean bean) throws InvalidInputDetailException;
	Double showBalance(Long accountNumber) throws AccountExistException;
	Double deposit(Double depositAmount, Long accountNumber) throws AccountExistException;
	Double withdraw(Double withdrawAmount, Long accountNumber) throws InsufficientAmountException, AccountExistException;
	Double fundTransfer(Double amount, Long sourceAccNumber, Long receiverAccNumber) throws InsufficientAmountException, AccountExistException;
	ArrayList<String> printTransaction(Long accountNumber) throws AccountExistException;
}
