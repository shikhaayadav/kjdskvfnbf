package com.capgemini.exception;

@SuppressWarnings("serial")
public class AccountExistException extends Exception{
	public AccountExistException(String message) {
		super(message);
	}
}
