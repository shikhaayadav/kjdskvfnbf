package lab13.com.erd.ui;

import java.util.List;
import java.util.Scanner;

import lab13.com.erd.bean.Author;
import lab13.com.erd.bean.Book;
import lab13.com.erd.service.ERDService;

public class Starter {

	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		char repeatChoice='y';
		ERDService serviceObj = new ERDService();
		Book book = new Book();
		Author author = new Author();
		
		do {
			System.out.println("Welcome to our Application");
			System.out.println("Please select following options");
			System.out.println("Press 1. Insert Operation");
			System.out.println("Press 2. Show Details");
			System.out.println("Press 3. Update");
			int choice = sc.nextInt();
			sc.nextLine();
			int row = 0;
			switch(choice) {
				case 1:
					System.out.println("Enter Book Title");
					String title = sc.next();
					System.out.println("Enter Book Price");
					Double price = sc.nextDouble();
					System.out.println("Enter Author Name");
					String name = sc.next();
					book.setTitle(title);
					book.setPrice(price);
					author.setName(name);
					row = serviceObj.insertDetails(book, author);
					System.out.println(row+" row inserted");
					break;
				
				case 2:
					System.out.println("Enter author name");
					String authorName = sc.next();
					List<String> list = serviceObj.getValues(authorName);
					for(String map: list)
						System.out.println(map);
					break;
				
				case 3:
					System.out.println("Enter the isbn");
					Integer book_id = sc.nextInt();
					System.out.println("Enter the new price");
					Double newPrice = sc.nextDouble();
					row = serviceObj.updateElement(book_id, newPrice);
					break;
					
				default:
					System.out.println("Please make a valid choice");
			}
			System.out.println("Do you want to continue. Press y or n");
			repeatChoice = sc.next().charAt(0);
		}while(repeatChoice=='y' || repeatChoice=='Y');
		sc.close();
		System.out.println("Thank you for using our service. ");
	}
}

