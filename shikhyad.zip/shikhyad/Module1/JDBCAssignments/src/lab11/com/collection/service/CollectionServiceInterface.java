package lab11.com.collection.service;

import java.util.List;

import lab11.com.collection.bean.CollectionBean;

public interface CollectionServiceInterface {

	int addElement(CollectionBean beanObj);
	int deleteElement(Integer key);
	List<CollectionBean> getValues();
}
