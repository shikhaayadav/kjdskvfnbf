package lab11.com.collection.service;

import java.util.List;

import lab11.com.collection.bean.CollectionBean;
import lab11.com.collection.dao.CollectionDao;

public class CollectionService {
	
	CollectionDao daoObj = new CollectionDao();

	// method to call dao object to add a row in  table
	public int addElement(CollectionBean beanObj) {
		return daoObj.addElement(beanObj);	
	}
	
	// method to call dao object to delete the details
	public int deleteElement(Integer key) {
		return daoObj.deleteElement(key);
	}
	
	// method to call dao object to retrieve the data
	public List<CollectionBean> getValues() {
		return daoObj.getValues();
	}
}
