package lab11.com.collection.ui;

import java.util.List;
import java.util.Scanner;

import lab11.com.collection.bean.CollectionBean;
import lab11.com.collection.service.CollectionService;

public class CollectionUI {

	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		CollectionBean beanObj = new CollectionBean();
		CollectionService serviceObj = new CollectionService();
		char repeatedChoice='y';
		int row = 0; 
		Integer key = null;
		do {
			System.out.println("Press 1. Insert row");
			System.out.println("Press 2. Delete row");
			System.out.println("Press 3. Retrieve rows");
			System.out.println("Enter your choice");
			int choice = sc.nextInt();
			switch(choice) {
			
				// if user want to insert a row in the table
				case 1:
					System.out.println("Enter Key");
					key = sc.nextInt();
					System.out.println("Enter value");
					String value = sc.next();
					beanObj.setKey(key);
					beanObj.setValue(value);
					row = serviceObj.addElement(beanObj);
					System.out.println(row+" row inserted");
					break;
				
				// if user want to delete a row from the table
				case 2:
					System.out.println("Enter Key");
					key = sc.nextInt();
					row = serviceObj.deleteElement(key);
					System.out.println(row+" row deleted");
					break;
				
				// retrieve table data
				case 3:
					List<CollectionBean> list = serviceObj.getValues();
					for(CollectionBean map: list)
						System.out.println(map.getKey()+"  "+map.getValue());
					break;
					
				default:
					System.out.println("Please enter valid choice");
			}
			System.out.println("Do you want to continue. Press y or n");
			repeatedChoice = sc.next().charAt(0);
		}while(repeatedChoice=='y' || repeatedChoice=='Y');
		
		System.out.println("Thank You!!!");
		sc.close();
	}
}
