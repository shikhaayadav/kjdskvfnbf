package lab11.com.collection.dao;

import java.util.List;

import lab11.com.collection.bean.CollectionBean;

public interface CollectionDaoInterface {

	int addElement(CollectionBean beanObj);
	int deleteElement(Integer key);
	List<CollectionBean> getValues();
}
