package lab11.com.collection.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import lab11.com.collection.bean.CollectionBean;
import lab11.com.collection.util.DatabaseConnection;
public class CollectionDao {

	Connection con=null;
	PreparedStatement ps = null;
	ResultSet rs = null;
	int row = 0;
	
	// method to add a row in the table
	public int addElement(CollectionBean beanObj) {
		try {
			con = DatabaseConnection.getConnection();
			String sql = "insert into map values(?,?)";
			ps = con.prepareStatement(sql);
			ps.setInt(1, beanObj.getKey());
			ps.setString(2, beanObj.getValue());
			row = ps.executeUpdate();
		}
		catch(Exception e) {
			System.out.println("Error Occurred while establishing connection");
		}
		finally {
			if(con!=null) {
				try {
					ps.close();
					con.close();
				}
				catch(SQLException e) {
					System.out.println("Your Collection is not properly closed.");
				}
			}
		}
		return row;
	}
	
	// method to delete a row from the table
	public int deleteElement(Integer key) {
		try {
			con = DatabaseConnection.getConnection();
			String sql = "Delete from map where mapId=?";
			ps = con.prepareStatement(sql);
			ps.setInt(1, key);
			row = ps.executeUpdate();
		}
		catch(Exception e) {
			System.out.println("Error Occurred while establishing connection");
		}
		finally {
			if(con!=null) {
				try {
					ps.close();
					con.close();
				}
				catch(SQLException e) {
					System.out.println("Your Collection is not properly closed.");
				}
			}
		}
		return row;
	}
	
	
	// method to retrieve the data from the table
	public List<CollectionBean> getValues() {
		List<CollectionBean> list = new ArrayList<CollectionBean>();
		try {
			con = DatabaseConnection.getConnection();
			String sql = "Select * from map order by element";
			ps = con.prepareStatement(sql);
			rs = ps.executeQuery();
			while(rs.next()) {
				CollectionBean bean = new CollectionBean();
				bean.setKey(rs.getInt("mapid"));
				bean.setValue(rs.getString("element"));
				list.add(bean);
			}
			
		}
		catch(Exception e) {
			System.out.println("Error Occurred while establishing connection");
		}
		finally {
			if(con!=null) {
				try {
					rs.close();
					ps.close();
					con.close();
				}
				catch(SQLException e) {
					System.out.println("Your Collection is not properly closed.");
				}
			}
		}
		return list;
	}
}
