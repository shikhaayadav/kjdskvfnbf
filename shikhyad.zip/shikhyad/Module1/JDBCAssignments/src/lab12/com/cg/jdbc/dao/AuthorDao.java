package lab12.com.cg.jdbc.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import lab12.com.cg.jdbc.bean.AuthorBean;
import lab12.com.cg.jdbc.util.GetConnection;

public class AuthorDao {

	int row = 0;
	Connection con=null;
	PreparedStatement ps = null;
	ResultSet rs = null;
	
	// method to add a row in the author table
	public int addAuthor(AuthorBean beanObj) {
		
		try {
			con = GetConnection.getConnection();
			String sql = "insert into author values(?,?,?,?,?)";
			ps = con.prepareStatement(sql);
			ps.setInt(1, beanObj.getAuthorId());
			ps.setString(2, beanObj.getFirstName());
			ps.setString(3, beanObj.getMiddleName());
			ps.setString(4, beanObj.getLastName());
			ps.setLong(5,beanObj.getPhoneNo());
			row = ps.executeUpdate();
		}
		catch(Exception e) {
			System.out.println("Error Occurred while establishing connection");
		}
		finally {
			if(con!=null) {
				try {
					ps.close();
					con.close();
				}
				catch(SQLException e) {
					System.out.println("Your Collection is not properly closed.");
				}
			}
		}
		return row;
	}
	
	// method to update the details of author
	public int updateAuthor(Integer authorId, Long number) {
		try {
			con = GetConnection.getConnection();
			String sql = "update author set phoneNo=? where authorId=?";
			ps = con.prepareStatement(sql);
			ps.setLong(1, number);
			ps.setInt(2, authorId);
			row = ps.executeUpdate();
		}
		catch(Exception e) {
			System.out.println("Error Occurred while establishing connection");
		}
		finally {
			if(con!=null) {
				try {
					ps.close();
					con.close();
				}
				catch(SQLException e) {
					System.out.println("Your Collection is not properly closed.");
				}
			}
		}
		return row;
	}
	
	// method to delete a row from the author table
	public int deleteAuthor(Integer authorId) {
		try {
			con = GetConnection.getConnection();
			String sql = "Delete from author where authorId=?";
			ps = con.prepareStatement(sql);
			ps.setInt(1, authorId);
			row = ps.executeUpdate();
		}
		catch(Exception e) {
			System.out.println("Error Occurred while establishing connection");
		}
		finally {
			if(con!=null) {
				try {
					ps.close();
					con.close();
				}
				catch(SQLException e) {
					System.out.println("Your Collection is not properly closed.");
				}
			}
		}
		return row;
	}
	
	// method to get the values of author from the table
	public List<AuthorBean> getAuthor() {
		List<AuthorBean> list = new ArrayList<AuthorBean>();
		try {
			con = GetConnection.getConnection();
			String sql = "Select * from author";
		
			ps = con.prepareStatement(sql);
			rs = ps.executeQuery();
			while(rs.next()) {
				AuthorBean bean = new AuthorBean();
				bean.setAuthorId(rs.getInt("authorid"));
				bean.setFirstName(rs.getString("firstName"));
				bean.setMiddleName(rs.getString("middleName"));
				bean.setLastName(rs.getString("lastname"));
				bean.setPhoneNo(rs.getLong("phoneNo"));
				list.add(bean);
			}
			
		}
		catch(Exception e) {
			System.out.println("Error Occurred while establishing connection");
		}
		finally {
			if(con!=null) {
				try {
					rs.close();
					ps.close();
					con.close();
				}
				catch(SQLException e) {
					System.out.println("Your Collection is not properly closed.");
				}
			}
		}
		return list;
	}
	
}
