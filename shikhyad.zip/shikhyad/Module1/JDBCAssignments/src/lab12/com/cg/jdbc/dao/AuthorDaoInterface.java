package lab12.com.cg.jdbc.dao;

import java.util.List;

import lab12.com.cg.jdbc.bean.AuthorBean;

public interface AuthorDaoInterface {

	int addAuthor(AuthorBean beanObj);
	int updateAuthor(Integer authorId, Long number);
	int deleteAuthor(Integer authorId);
	List<AuthorBean> getAuthor();
}
