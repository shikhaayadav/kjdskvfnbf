package lab12.com.cg.jdbc.service;

import java.util.List;

import lab12.com.cg.jdbc.bean.AuthorBean;
import lab12.com.cg.jdbc.dao.AuthorDao;

public class AuthorService {

	AuthorDao daoObj = new AuthorDao();
	
	// method to call dao object to add a row in author table
	public int addAuthor(AuthorBean beanObj) {
		int row = daoObj.addAuthor(beanObj);
		return row;	
	}
	
	// method to call dao object to update the details of author
	public int updateAuthor(Integer authorId, Long number) {
		int row = daoObj.updateAuthor(authorId, number);
		return row;
	}
	
	// method to call dao object to delete a row from author
	public int deleteAuthor(Integer authorId) {
		int row = daoObj.deleteAuthor(authorId);
		return row;
	}
	
	// method to call dao object to retrieve the rows from author table
	public List<AuthorBean> displayAuthor() {
		List<AuthorBean> list = daoObj.getAuthor();
		return list;
	}
}
