package lab12.com.cg.jdbc.service;

import java.util.List;

import lab12.com.cg.jdbc.bean.AuthorBean;

public interface AuthorServiceInterface {

	int addAuthor(AuthorBean beanObj);
	int updateAuthor(Integer authorId, Long number);
	int deleteAuthor(Integer authorId);
	List<AuthorBean> displayAuthor();
}
