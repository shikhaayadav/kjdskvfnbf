package lab12.com.cg.jdbc.ui;

import java.util.List;
import java.util.Scanner;

import lab12.com.cg.jdbc.bean.AuthorBean;
import lab12.com.cg.jdbc.service.AuthorService;

public class AuthorMain {

	public static void main(String args[]) {
		AuthorBean beanObj = new AuthorBean();
		AuthorService serviceObj = new AuthorService();
		Scanner sc = new Scanner(System.in);
		char repeatChoice='y';
		
		do {
			System.out.println("Welcome to our Application.");
			System.out.println("Please select following options");
			System.out.println("Press 1. Insert Author Details");
			System.out.println("Press 2. Update Author Details");
			System.out.println("Press 3. Delete Author Details");
			System.out.println("Press 4. Display Author Details");
			System.out.println("Enter your choice");
			Integer rows=0;
			int choice = sc.nextInt();
			switch(choice) {
			
				// if user want to insert a row in the table
				case 1:
					System.out.println("Enter Author Id");
					Integer authorId = sc.nextInt();
					System.out.println("Enter Author FirstName");
					String firstName = sc.next();
					System.out.println("Enter Author MiddleName");
					String middleName = sc.next();
					System.out.println("Enter Author LastName");
					String lastName = sc.next();
					System.out.println("Enter Author's Phone Number");
					Long phoneNumber = sc.nextLong();
					beanObj.setAuthorId(authorId);
					beanObj.setFirstName(firstName);
					beanObj.setMiddleName(middleName);
					beanObj.setLastName(lastName);
					beanObj.setPhoneNo(phoneNumber);
					rows = serviceObj.addAuthor(beanObj);
					System.out.println(rows+" row inserted");
					break;
				
				// if user want to update the details of author
				case 2:
					System.out.println("Enter Author Id");
					Integer authorId1 = sc.nextInt();
					System.out.println("Enter the new Mobile Number");
					Long newNumber = sc.nextLong();
					rows = serviceObj.updateAuthor(authorId1, newNumber);
					System.out.println(rows+" row updated");
					break;

				// if user want to delete a row from the table
				case 3:
					System.out.println("Enter Author Id");
					Integer authorId2 = sc.nextInt();
					rows = serviceObj.deleteAuthor(authorId2);
					System.out.println(rows+" row deleted");
					break;
				
				// if user want to retrieve the data from the table
				case 4:
					List<AuthorBean> list = serviceObj.displayAuthor();
					for(AuthorBean author: list)
						System.out.println(author.getAuthorId()+"  "+author.getFirstName()+"  "+author.getMiddleName()+"  "+author.getLastName()+"  "+author.getPhoneNo());
					break;
					
				default:
					System.out.println("Please enter valid choice");
			}
			System.out.println("Do you want to continue. Press y or n");
			repeatChoice = sc.next().charAt(0);
		}while(repeatChoice=='y' || repeatChoice=='Y');
		System.out.println("Thank You!");
		sc.close();
	}
}
