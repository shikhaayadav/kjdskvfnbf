package lab2.assignments;

public abstract class Item {
	private int idNumber;
	private String title;
	private int numOfCopies;
	
	public Item() {
		idNumber = 0;
		title = " ";
		numOfCopies = 0;
	}

	public Item(int idNumber, String title, int numCopies) {
		super();
		this.idNumber = idNumber;
		this.title = title;
		this.numOfCopies = numCopies;
	}

	public int getIdNumber() {
		return idNumber;
	}

	public void setIdNumber(int idNumber) {
		this.idNumber = idNumber;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public int getNumOfCopies() {
		return numOfCopies;
	}

	public void setNumCopies(int numOfCopies) {
		this.numOfCopies = numOfCopies;
	}
	
	public void checkIn() {
		numOfCopies+=1;
	}
	
	public void checkOut() {
		numOfCopies-=1;
	}
	
	public void addItem(int id, String str, int number) {
		setIdNumber(id);
		setTitle(str);
		setNumCopies(number);
	}

	@Override
	public String toString() {
		return "Item [idNumber=" + idNumber + ", title=" + title + ", numOfCopies=" + numOfCopies + "]";
	}
	
	public void print() {
		System.out.println("ID Number: "+idNumber);
		System.out.println("Title: "+title);
		System.out.println("Number of Copies: "+numOfCopies);
	}
	
	@Override
	public boolean equals(Object obj) {
		if(obj==null)
			return false;
		Item otherItem = (Item) obj;
		return idNumber == otherItem.idNumber && title == otherItem.title && numOfCopies == otherItem.numOfCopies;
	}
	
}
