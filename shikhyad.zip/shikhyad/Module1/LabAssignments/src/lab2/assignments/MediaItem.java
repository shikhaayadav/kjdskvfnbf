package lab2.assignments;

public abstract class MediaItem {

		private int runTime;
		class Video extends MediaItem{}
		class CD extends MediaItem{}
		public boolean equals(Object obj){
			if(obj == null)
				return false;
			MediaItem otherMediaItem = (MediaItem) obj;
			return super.equals(otherMediaItem) && runTime == otherMediaItem.runTime;
		}
}

