package lab2.assignments;

public abstract class WrittenItem extends Item {

	private String author;
	void setAuthor(String str){
		author = str;
	}
	
	String getAuthor(){
		return author;
	}
	
	public int getidNum(){
		return super.getIdNumber();
	}
	
	public String getTitle(){
		return super.getTitle();
	}
	
	public int getNumCopies(){
		return super.getNumOfCopies();
	}
	
	public boolean equals(Object obj){
		if(obj == null)
			return false;
		WrittenItem otherWrittenItem = (WrittenItem) obj;
		return super.equals(otherWrittenItem) && author == otherWrittenItem.author;
	}
	
	public void print() {}

	public String getTitle1() {	
		return null;
	}
	
	public int getidNum1() {	
		return 0;
	}
	
	public void addItem() {}
	
	public void checkIn() {}
}
