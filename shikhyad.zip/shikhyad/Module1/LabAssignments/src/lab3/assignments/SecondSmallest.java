package lab3.assignments;

import java.util.Scanner;

public class SecondSmallest {
	
public static void main(String args[]) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size of array :");
		int size = sc.nextInt();
		int array[] = new int[size];
		for(int counter=0 ;counter<size ; counter++)
		{
			array[counter]=sc.nextInt();
		}
		SecondSmallest obj = new SecondSmallest();
		int secSmallest=obj.getSecondSmallest(array);
		System.out.println("The second smallest element is : "+ secSmallest);
		sc.close();
	}

	// method to calculate the second smallest number from an array
	public int getSecondSmallest(int[] arr){
		int smallest=arr[0];
		int secondSmallest=arr[0];
		int n=arr.length;
		for(int i=1 ; i<n ; i++){
			if(smallest>arr[i])
				smallest=arr[i];
		}
		for(int i=0 ; i<n ; i++){
			if(secondSmallest>arr[i] && arr[i]>smallest ){
				if(arr[i]!=smallest)
					secondSmallest=arr[i];
			}
		}
		return secondSmallest;
	}
}

