package lab3.assignments;

import java.util.Arrays;
import java.util.Scanner;

public class SortArrayInUpperAndLowerCase {
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size of String objects : ");
		int n=sc.nextInt();
		String str[] = new String[n];
		for(int i=0; i<n ; i++) {
			str[i]=sc.next();
		}
		SortArrayInUpperAndLowerCase obj = new SortArrayInUpperAndLowerCase();
		String sortedArray[] = obj.getSortedArray(str);
		for(int i=0 ; i<n ; i++)
			System.out.println(sortedArray[i]);
		sc.close();
	}
	
	// method to sort array in upper and lower case
	public String[] getSortedArray(String str[]) {
		Arrays.sort(str);
		int size=str.length;
		for(int i=0 ; i<size ; i++) {
				if((size%2)==0) {
					if(i<(size/2))
						str[i]=str[i].toUpperCase();
					else
						str[i]=str[i].toLowerCase();
				}
				else
					if(i<=(size)/2)
						str[i]=str[i].toUpperCase();
					else
						str[i]=str[i].toLowerCase();
		}
		return str;
	}
}
