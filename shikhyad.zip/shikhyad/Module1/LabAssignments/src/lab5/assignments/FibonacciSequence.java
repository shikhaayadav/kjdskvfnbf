package lab5.assignments;

import java.util.Scanner;

public class FibonacciSequence {
	public static void main(String args[]) {
		FibonacciSequence obj = new FibonacciSequence();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the value of n to print the fibonacci series");
		int number = sc.nextInt();
		System.out.println("Press 1. For Recursive Method");
		System.out.println("Press 2. For Non-Recursive Method");
		int choice =sc.nextInt();
		switch(choice) {
		case 1:
			int nthvalue1=obj.recursiveFibonacci(number);
			System.out.println(number+" value of fibonacci series is : "+nthvalue1);
		case 2:
			int nthvalue2=obj.nonRecursiveFibonacci(number);
			System.out.println(number+" value of fibonacci series is : "+nthvalue2);
			break;
		}
		sc.close();
	}
	
	// method to print the nth value of a fibonacci sequence using non recursive function
	public int nonRecursiveFibonacci(int number) {
		int nthvalue=0, firstNumber=1, secondNumber=1;
		for(int i=2 ; i<number ; i++) {
			nthvalue=firstNumber+secondNumber;
			firstNumber=secondNumber;
			secondNumber=nthvalue;
		}
		return nthvalue;
	}
	
	// method to print the nth value of a fibonacci sequence using recursive function
	public int recursiveFibonacci(int number) {
		if(number<=1)
			return number;
		else
			return (recursiveFibonacci(number-1)+recursiveFibonacci(number-2));
		
	}
}
