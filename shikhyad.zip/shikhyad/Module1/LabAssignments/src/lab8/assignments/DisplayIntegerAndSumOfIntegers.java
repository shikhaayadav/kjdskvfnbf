package lab8.assignments;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class DisplayIntegerAndSumOfIntegers {

		public static void main(String[]args) {
			DisplayIntegerAndSumOfIntegers obj = new DisplayIntegerAndSumOfIntegers();
			try {
				obj.sumOfIntegers();
			} 
			catch (IOException e) {
				System.out.println(e.getMessage());
			}
		}
		
		//method to get integers and calculate the sum of integers
		public void sumOfIntegers() throws IOException{
			int sumOfIntegers=0;
			int id;
			System.out.println("Enter the integers");
			BufferedReader reader=new BufferedReader(new InputStreamReader(System.in));
			String emp=reader.readLine();
			StringTokenizer stokenizer= new StringTokenizer(emp, " ");
			
			//using String Tokenizer class to get input
			while(stokenizer.hasMoreTokens()) {
				String word= stokenizer.nextToken();
				id=Integer.parseInt(word);
				System.out.println(id);
				sumOfIntegers=sumOfIntegers+id;
			}
			System.out.println("sum of the numbers :"+sumOfIntegers);
			reader.close();
		}
}
