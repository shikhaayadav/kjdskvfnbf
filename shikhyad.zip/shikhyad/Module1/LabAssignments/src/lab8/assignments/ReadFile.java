package lab8.assignments;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.LineNumberInputStream;

@SuppressWarnings("deprecation")
public class ReadFile {

		public static void main(String[] args)throws IOException
		{
			FileInputStream fil;
			LineNumberInputStream line;
			
			int i;
			try
			{
				fil=new FileInputStream("C:\\Users\\shikhyad\\Lab Assignments\\LabAssignments\\src\\lab8\\assignments\\abc.txt");
				line=new LineNumberInputStream(fil);
			}
			catch(FileNotFoundException e)
			{
				System.out.println("No such file found");
				return;
			}
			
			// reading an existing file and prints on another with line number before each line
			do
			{
				i=line.read();
				if(i=='\n')
				{
					System.out.println();
					System.out.print(line.getLineNumber()+" ");
				}
				else
					System.out.print((char)i);
			}while(i!=-1);
			fil.close();
			line.close();
		}
}
