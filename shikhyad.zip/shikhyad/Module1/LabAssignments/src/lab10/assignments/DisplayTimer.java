package lab10.assignments;

public class DisplayTimer implements Runnable  {
	    @Override
	    
	    //display timer where timer will get refresh after every 10seconds.
	    public void run() {
	        long start_time = System.currentTimeMillis();
	        while (true) {
	            long current_time = System.currentTimeMillis() - start_time;

	            long seconds = (current_time / 1000) % 60;
	            long minutes = (current_time / 1000) / 60;

	            System.out.println(seconds + " seconds , " + minutes + " minutes.");

	            try {
	                Thread.sleep(10000);
	            } catch (InterruptedException ex) {
	                System.out.println("Timer Stopped");
	            }
	        }
	    }

	    public static void main(String[] args) {
	    	DisplayTimer timer = new DisplayTimer();
	        Thread thread = new Thread(timer);
	        thread.start();
	    }
}
