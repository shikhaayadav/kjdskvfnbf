package lab9.assignments;

import java.util.HashMap;
import java.util.Scanner;

public class NumbersAndTheirSquares {

	@SuppressWarnings("rawtypes")
	public static void main (String[] args)  {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number of elements you want to enter.");
		int size = sc.nextInt();
		int numbers[] = new int[size];
		for(int i=0; i<size; i++)
			numbers[i] = sc.nextInt();
		HashMap map = new HashMap();
		map = getSquares(numbers);
		System.out.println(map);
		sc.close();
	}
	
	//method to add elements in HashMap from an integer array 
	// add number as key and it's square as the value
	@SuppressWarnings({ "rawtypes", "unused", "unchecked" })
	static HashMap getSquares(int numbers[]) {
		int squaresOfIntegers = 0;
		HashMap map = new HashMap();
		for(int i=0; i<numbers.length; i++) {
			map.put(numbers[i], numbers[i]*numbers[i]);
		}
		return map;
		
	}
	
}