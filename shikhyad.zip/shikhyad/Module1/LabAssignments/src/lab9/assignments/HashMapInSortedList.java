package lab9.assignments;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

public class HashMapInSortedList {
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number of values you want to enter in HasMap :");
		int size = sc.nextInt();
		String values ;
		int counter=1;
		HashMap map = new HashMap();
		
		// taking the values of HashMap from user
		while(counter<=size) {
			System.out.println("Enter value of key "+counter);
			values = sc.next();
			map.put(counter, values);
			counter++;
		}
		HashMapInSortedList obj = new HashMapInSortedList();
		List list = obj.getValues(map);
		System.out.println(list);
		sc.close();
	}
	
	//add HashMap elements into List and sort them
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List getValues(HashMap map) {
		List list = new ArrayList();
		int length=map.size();
		for(int i=1; i<=length; i++) {
			list.add(map.get(i));
		}
		list.sort(null);
		return list;
	}
}
