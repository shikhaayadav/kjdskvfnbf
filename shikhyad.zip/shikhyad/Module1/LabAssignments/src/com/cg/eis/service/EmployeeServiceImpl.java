package com.cg.eis.service;

import java.util.List;
import java.util.Map;

import com.cg.eis.bean.Employee;
import com.cg.eis.dao.*;
import com.cg.eis.exception.InvalidDetailsException;

/**
 * @author shikhyad
 * @Description call the methods of dao to create, manipulate or delete the employee data
 *
 */
public class EmployeeServiceImpl implements EmployeeService {

	EmployeeDAO dao = new EmployeeDAOImpl();
	
	public boolean addEmployee(Employee e) {
		return dao.addEmployee(e);
	}

	public boolean updateEmployee(Employee e) {
		return dao.updateEmployee(e);
	}


	public boolean deleteEmployee(Employee e) {
		return dao.deleteEmployee(e);
	}


	public Employee findEmployee(int e_id) {
		return dao.findEmployee(e_id);
	}

	public Map<Integer,Employee> getAllEmployee() {
		return dao.getAllEmployee();
	}

	
	public String getScheme( double salary, String e_designation) throws InvalidDetailsException {
		return dao.getScheme( salary, e_designation);
	}


	public double getSumOfSalary(List<lab13.com.cg.api.bean.Employee> elist) {
		return 0;
	}

	public List<Employee> getEmployeeWithoutDept(List<lab13.com.cg.api.bean.Employee> elist) {
		return null;
	}


	public List<String> getSalInc(List<lab13.com.cg.api.bean.Employee> elist) {
		return null;
	}

	
	public List<lab13.com.cg.api.bean.Employee> didnotHaveManager(List<lab13.com.cg.api.bean.Employee> elist) {
		return null;
	}

	public List<lab13.com.cg.api.bean.Employee> sortName(List<lab13.com.cg.api.bean.Employee> elist) {
		return null;
	}

	public List<lab13.com.cg.api.bean.Employee> sortEmpId(List<lab13.com.cg.api.bean.Employee> elist) {
		return null;
	}

	public List<lab13.com.cg.api.bean.Employee> sortDeptId(List<lab13.com.cg.api.bean.Employee> elist) {
		return null;
	}


	public void printEmployeedetails(Employee e) {}	
}

