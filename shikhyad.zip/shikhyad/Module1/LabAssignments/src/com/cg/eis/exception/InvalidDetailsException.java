package com.cg.eis.exception;

@SuppressWarnings("serial")
public class InvalidDetailsException extends Exception {
	
	//Exception raises when employees does'nt fall in any category and salary range is matching with designation...	
		public InvalidDetailsException(String msg) {
			// TODO Auto-generated constructor stub
			super (msg);
			
		}
		@Override
		public String toString() {
			return "InvalidInputException - "+super.getMessage();
		}
	}