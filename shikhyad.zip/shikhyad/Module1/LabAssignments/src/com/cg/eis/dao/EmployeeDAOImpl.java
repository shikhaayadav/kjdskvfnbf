package com.cg.eis.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.InvalidDetailsException;

public class EmployeeDAOImpl implements EmployeeDAO {
	
static Map<Integer,Employee> emmap = new HashMap<Integer,Employee>();
	
	// method to add employees in map(collection)
	public boolean addEmployee(Employee e) {
		emmap.put(e.getE_id(), e);
		return true;
	}

	// method to update the details of an employee
	public boolean updateEmployee(Employee e) {
		
        emmap.put(e.getE_id(), e);
		return true;
	}

	// method to delete the employee from the map
	public boolean deleteEmployee(Employee e) {
		
		emmap.remove(e);
		return true;
	}

	// method to search if the employee is exist
	public Employee findEmployee(int e_id) {
		
		Employee e= emmap.get(e_id);
		return e;
	}

	// method to return the employee (return map collection)
	public Map<Integer, Employee> getAllEmployee() {
		
		return emmap;
	}

	// method to know the scheme according to the employee's salary and designation
	public String getScheme( double salary, String e_designation) throws InvalidDetailsException {
		
		if(((salary>=5000)&&(salary<20000))&&(e_designation.equalsIgnoreCase("System Associate")))
				{
			     return "Scheme C";
				}
		else if(((salary>=20000)&&(salary<40000))&&(e_designation.equalsIgnoreCase("Programmer")))
		{
	     return "Scheme B";
		}
		
		else if((salary>=40000)&&(e_designation.equalsIgnoreCase("Manager")))
		{
	     return "Scheme A";
		}
		
		else if((salary<5000)&&(e_designation.equalsIgnoreCase("Clerk")))
		{
	     return "No Scheme";
		}
		
		else 
		{
			throw new InvalidDetailsException("Salary Range is not matching with Designation of an Employee...Enter Correct Details");

	     
		}
		
	}

}
