package com.cg.eis.dao;

import com.cg.eis.bean.*;
import com.cg.eis.exception.InvalidDetailsException;

import java.util.Map;

public interface EmployeeDAO {
	
	
	public boolean addEmployee(Employee e);
	public boolean updateEmployee(Employee e);
	public boolean deleteEmployee(Employee e);
	public Employee findEmployee(int e_id);
	public Map <Integer,Employee> getAllEmployee();
    public String getScheme( double salary, String e_designation) throws InvalidDetailsException; 


}
