package lab13.assignments;

import java.util.Scanner;
import java.util.function.UnaryOperator;

public class StringFormat {

	public static void main(String[] args) {
	
		// string formatting i.e add a space in a string after each character
		UnaryOperator<String>uo=(str)->
		{String res =" ";
			for (int i = 0; i < str.length(); i++) {
			res+=str.charAt(i);
			if (i==str.length()-1) 
				break;
				res +=" ";
			
		}
			return res;
			};
			Scanner sc=new Scanner(System.in);
			System.out.println("enter string");
			String s=uo.apply(sc.nextLine());
			System.out.println(s);
			sc.close();
	}
}
