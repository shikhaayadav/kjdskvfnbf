package lab13.assignments;

import java.util.Scanner;

interface Power
{
	public double powerOfTwo(int a,int b);
}

public class AcceptsTwoValues {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);	
		System.out.println("Enter the base:");
		int base = sc.nextInt();
		System.out.println("Enter the power: ");
		int power = sc.nextInt();
		
		// calculate the power using lambda expression
		Power p=(a,b)->Math.pow(base, power);
		double result = p.powerOfTwo(base, power);
		System.out.println(result);
		sc.close();
	}


}
