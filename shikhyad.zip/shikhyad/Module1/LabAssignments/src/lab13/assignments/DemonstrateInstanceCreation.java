package lab13.assignments;

import java.util.Scanner;


public class DemonstrateInstanceCreation {

	private int num1;
	
	public int getNum1() {
		return num1;
	}
	public void setNum1(int num1) {
		this.num1 = num1;
	}
	
	// method to find if the number is even or odd
	public void findEvenOdd(int num1) {
		
		if(num1%2==0)
			System.out.println(num1+" is even number");
		else
			System.out.println(num1+" is odd number");
	
	}
	
	// demonstrate constructor reference using a function
	public static void main(String[] args) {
		System.out.println("please enter the numbers  :");
		Scanner sc= new Scanner(System.in);
		int a= sc.nextInt();
		DemonstrateInstanceCreation ld= new DemonstrateInstanceCreation();
		InstanceInterface x=ld::findEvenOdd;
		x.bigger(a);
		sc.close();
	}


}
