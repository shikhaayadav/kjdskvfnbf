package lab13.assignments;

public interface FactorialInterface {

	public void factorial(int a);

}
