package lab13.assignments;

import java.util.Scanner;

public class CalculateFactorial {

	public void factorial(int num) {
		int f=1;
		if(num==0)
			System.out.println("Factorial :1");
		else {
			for(int i=1;i<=num;i++)
				f = f*i;
			System.out.println("Factorial is : "+f);
		}
	}

	// calculate factorial using method reference
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number");
		int num=sc.nextInt();
		CalculateFactorial fact = new CalculateFactorial();
		FactorialInterface fa = fact::factorial;
		fa.factorial(num);
		sc.close();
	}
}
