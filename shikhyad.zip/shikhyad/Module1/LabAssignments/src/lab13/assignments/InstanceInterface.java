package lab13.assignments;

public interface InstanceInterface {

	void bigger(int a);
}
