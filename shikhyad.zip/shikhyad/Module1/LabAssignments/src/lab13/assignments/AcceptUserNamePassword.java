package lab13.assignments;

import java.util.Scanner;
import java.util.function.BiPredicate;

public class AcceptUserNamePassword {

	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		
		// using BiPredicate Interface to check if the username and password are correct
		BiPredicate<String, String> biPredicate = (username,password) -> {
			if(username.equals("System") && password.equals("root"))
				return true;
			else
				return false;
		};
		System.out.println("Enter Username: ");
		String username = sc.nextLine();
		System.out.println("Enter Password: ");
		String password = sc.nextLine();
		System.out.println(biPredicate.test(username,password));
		sc.close();
	}
}
