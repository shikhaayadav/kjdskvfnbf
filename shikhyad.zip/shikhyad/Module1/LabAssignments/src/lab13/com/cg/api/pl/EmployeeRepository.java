package lab13.com.cg.api.pl;

import java.time.LocalDate;
import java.util.*;

import lab13.com.cg.api.bean.*;


public class EmployeeRepository {

	 public static List<Department> getDepartments() {
		List<Department> deptList=new ArrayList<>();
		deptList.add(new Department(1001,"Accounts",100));
		deptList.add(new Department(1002,"Sales",121));
		deptList.add(new Department(1003,"Marketing",107));
		deptList.add(new Department(1004,"HR",114));
		return deptList;
	 }
	 
	 public static List<Employee> getEmployees() {
		 List<Employee> empList=new ArrayList<>();
		 empList.add(new Employee(100,"Ved","Capgemini","ved@cg.com","9145637836",LocalDate.of(2011,5,25),"President",50000.00,null,new Department(1001,"Accounts",100)));
		 empList.add(new Employee(104,"Prerna","Capgemini","prerna@cg.com","9867221100",LocalDate.of(2015,8,2),"Sales_Mgr",45000.00,100,null));
		 empList.add(new Employee(101,"Amrit","Capgemini","amrit@cg.com","9867221020",LocalDate.of(2013,8,2),"Sales_Mgr",45000.00,100,new Department(40,"Sales",101)));
		 empList.add(new Employee(102,"Gokul","Capgemini","gokul@cg.com","8143790342",LocalDate.of(2011,7,21),"Marketing",15000.00,100,new Department(1003,"Marketing",107)));
		 empList.add(new Employee(103,"Shalini","Capgemini","shalini@cg.com","874569632",LocalDate.of(2012,8,2),"Sales_Mgr",45000.00,100,null));
		 empList.add(new Employee(106,"Jagrati","Capgemini","jagrat@cg.com","8767221020",LocalDate.of(2015,8,2),"Sales_Mgr",45000.00,100,new Department(1002,"Sales",121)));
		 return empList;
	 }

}

