package com.capgemini.paymentwallet.junit;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.HashMap;

import org.junit.jupiter.api.Test;

import com.capgemini.exception.AccountExistException;
import com.capgemini.exception.InsufficientAmountException;
import com.capgemini.exception.InvalidInputDetailException;
import com.capgemini.paymentwallet.bean.PaymentWalletBean;
import com.capgemini.paymentwallet.dao.PaymentWalletDao;
import com.capgemini.paymentwallet.service.PaymentWalletService;

public class PaymentWalletJunit {

	PaymentWalletService serviceObj = new PaymentWalletService();
	PaymentWalletBean beanObj = new PaymentWalletBean();
	PaymentWalletDao daoObj = new PaymentWalletDao();
	
	@Test
	public void testCreateAccount()  throws InvalidInputDetailException {
		beanObj.setName("Shikha");
		beanObj.setEmailId("shikha@gmail.com");
		beanObj.setMobileNumber("9457532790");
		beanObj.setBalance(1000.0);
		beanObj.setAccountNumber(122947765837l);
		boolean actualResult = daoObj.accountCreation(beanObj);
		assertTrue(actualResult);
	}
	@Test
	public void testShowBalance() throws AccountExistException{
		HashMap<Long,PaymentWalletBean >map = new HashMap<>();
		PaymentWalletBean acOpen = new PaymentWalletBean();
		acOpen.setName("Shikha");
		acOpen.setEmailId("shikha@gmail.com");
		acOpen.setMobileNumber("9457532790");
		acOpen.setBalance(1000.0);
		acOpen.setAccountNumber(122947765837l);	
		map.put(122947765837l, acOpen);
		daoObj.setMap(map);
		Double expectedResult=1000.0;
		Double actualResult = daoObj.showBalance(122947765837l);
		assertEquals(expectedResult,actualResult);
	}
	@Test
	public void testDeposit() throws AccountExistException {
		HashMap<Long,PaymentWalletBean >map = new HashMap<>();
		PaymentWalletBean acOpen = new PaymentWalletBean();
		acOpen.setName("Shikha");
		acOpen.setEmailId("shikha@gmail.com");
		acOpen.setMobileNumber("9457532790");
		acOpen.setBalance(1000.0);
		acOpen.setAccountNumber(122947765837l);	
		map.put(122947765837l, acOpen);
		daoObj.setMap(map);
		double expectedResult=2000;
		double actualResult =daoObj.depositAmt(1000.0, 122947765837l);
		assertEquals(expectedResult, actualResult);
	}
	
	@Test
	public void testWithdraw() throws AccountExistException, InsufficientAmountException {
		HashMap<Long,PaymentWalletBean >map = new HashMap<>();
		PaymentWalletBean acOpen = new PaymentWalletBean();
		acOpen.setName("Shikha");
		acOpen.setEmailId("shikha@gmail.com");
		acOpen.setMobileNumber("9457532790");
		acOpen.setBalance(1000.0);
		acOpen.setAccountNumber(122947765837l);	
		map.put(122947765837l, acOpen);
		daoObj.setMap(map);
		double expectedResult=500;
		double actualResult =daoObj.withdrawAmt(500.0, 122947765837l);
		assertEquals(expectedResult, actualResult);
	}
	
}
