package com.capgemini.paymentwallet.service;

import java.util.ArrayList;

import com.capgemini.exception.AccountExistException;
import com.capgemini.exception.InvalidInputDetailException;
import com.capgemini.exception.InsufficientAmountException;
import com.capgemini.paymentwallet.bean.PaymentWalletBean;
import com.capgemini.paymentwallet.dao.PaymentWalletDao;

public class PaymentWalletService implements PaymentWalletServiceInterface{
	
	PaymentWalletDao walletDaobj = new PaymentWalletDao();
	Long accNo=null;

	public Long createAccount(PaymentWalletBean walletBeanObj) throws InvalidInputDetailException{
		if(emailCheck(walletBeanObj.getEmailId()) && numberCheck(walletBeanObj.getMobileNumber()) && nameCheck(walletBeanObj.getName()) && walletBeanObj.getName().length()>=3) {
			accNo = Math.abs((Long.parseLong(walletBeanObj.getMobileNumber())-12341)*13);
			walletBeanObj.setAccountNumber(accNo);
			Boolean acc = walletDaobj.accountCreation(walletBeanObj);
		} 
		else {
			throw new InvalidInputDetailException("Error Occured!!!");
		}
		return accNo;
	}
	
	public Double showBalance(Long accountNumber) throws AccountExistException{
		Double balance = walletDaobj.showBalance(accountNumber);;
		if(balance==null)
			throw new AccountExistException("Account Number doesn't exist. Please check the account number");
		return balance;
	}
	
	public Double deposit(Double depositAmount, Long accountNumber) throws AccountExistException{
		Double updatedBal = walletDaobj.depositAmt(depositAmount, accountNumber);
		if(updatedBal==null)
			throw new AccountExistException("Account Number doesn't exist. Please check the account number");
		return updatedBal;
	}
	
	public Double withdraw(Double withdrawAmount, Long accountNumber) throws InsufficientAmountException, AccountExistException{
		Double updatedBal = walletDaobj.withdrawAmt(withdrawAmount, accountNumber);
		if(updatedBal==null)
			throw new AccountExistException("Account Number doesn't exist. Please check the account number");
		return updatedBal;
	}
	
	public Double fundTransfer(Double amount, Long sourceAccNumber, Long receiverAccNumber) throws InsufficientAmountException, AccountExistException{
		Double updatedBal = null;
		try {
			updatedBal = walletDaobj.transfer(amount, sourceAccNumber, receiverAccNumber);	
			if(updatedBal==null)
				throw new AccountExistException("Account Number doesn't exist. Please check the account number");
		}
		catch(AccountExistException e) {}
		catch (InsufficientAmountException e) {}
		return updatedBal;		
	}
	
	public ArrayList<String> printTransaction(Long accountNumber) throws AccountExistException{
		ArrayList<String> alist = walletDaobj.getTransactions(accountNumber);
		if(alist!=null)
				return alist;
			else 
				throw new AccountExistException("Account Number doesn't exist. Please check the account number");
	}		
	
	boolean nameCheck(String name) {
		boolean result = name.matches("^[a-zA-Z\\s]*$");
		return result;	
	}
	
	boolean emailCheck(String emailId) {
		boolean result = emailId.matches("^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$");
		return result;
	}
	
	boolean numberCheck(String mobile) {
		boolean result = false;
				if(mobile.length()==10 && mobile.charAt(0)!='0')
					result=true;
		return result;
		
	}
	
	public boolean accNoCheck(String acc) {
		boolean result = false;
		result = String.valueOf(acc).matches("[0-9]{9,18}");
		return result;
	}
}
