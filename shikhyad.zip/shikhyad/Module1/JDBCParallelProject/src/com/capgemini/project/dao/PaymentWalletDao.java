package com.capgemini.project.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import com.capgemini.collection.util.DatabaseConnection;
import com.capgemini.exception.AccountExistException;
import com.capgemini.exception.InsufficientAmountException;
import com.capgemini.project.bean.PaymentWalletBean;


public class PaymentWalletDao implements PaymentWalletDaoInterface {
	
	PaymentWalletBean bean = new PaymentWalletBean();
	ArrayList<String> alist= new ArrayList<String>();
	Boolean result = false;
	Connection con=null;
	PreparedStatement ps = null;
	ResultSet rs = null;
	int row = 0;

	public int accountCreation(PaymentWalletBean bean) throws SQLException {
		try {
			con = DatabaseConnection.getConnection();
			String sql = "insert into user values(?,?,?,?,?)";
			ps = con.prepareStatement(sql);
			ps.setString(1, bean.getName());
			ps.setLong(2, bean.getAccountNumber());
			ps.setString(3, bean.getEmailId());
			ps.setString(4, bean.getMobileNumber());
			ps.setDouble(5, bean.getBalance());
			row = ps.executeUpdate();
		}
		catch(Exception e) {
			throw new SQLException("Error Occurred while establishing connection");
		}
		finally {
			if(con!=null) {
				try {
					ps.close();
					con.close();
				}
				catch(SQLException e) {
					throw new SQLException("Your Connection is not properly closed.");
				}
			}
		}
		return row;
	}
	
	public Double showBalance(Long ano) throws AccountExistException, SQLException {
		try {
			con = DatabaseConnection.getConnection();
			String sql = "select balance from user where accNo=?";
			ps = con.prepareStatement(sql);
			ps.setLong(1, ano);
			rs = ps.executeQuery();
			if(rs.next()==false)
				throw new AccountExistException("Account Number doesn't exist. Please check the account number");
			bean.setBalance(rs.getDouble("balance"));
		} 
		catch (SQLException e) {
			throw new SQLException("Error Occurred while establishing connection");
		}
		
		finally {
			if(con!=null) {
				try {
					ps.close();
					con.close();
				}
				catch(SQLException e) {
					throw new SQLException("Your Connection is not properly closed.");
				}
			}
		}
		return bean.getBalance();
	}
	
	public Boolean depositAmt(Double depositAmount, Long accountNumber) throws AccountExistException, SQLException {
		try {
			con = DatabaseConnection.getConnection();
			String sql = "update user set balance=balance+? where accNo=?";
			ps = con.prepareStatement(sql);
			ps.setDouble(1, depositAmount);
			ps.setLong(2, accountNumber);
			row = ps.executeUpdate();
			if(row<1)
				throw new AccountExistException("Account Number doesn't exist. Please check the account number");
			alist.add("Rs. "+depositAmount +" deposited in account "+accountNumber);
			result = true;
		}
		catch(SQLException e) {
			throw new SQLException("Error Occurred while establishing connection");
		}
		finally {
			if(con!=null) {
				try {
					ps.close();
					con.close();
				}
				catch(SQLException e) {
					throw new SQLException("Your Connection is not properly closed.");
				}
			}
		}
		return result;
	}
	
	public Boolean withdrawAmt(Double withdrawAmount, Long accountNumber) throws AccountExistException, InsufficientAmountException, SQLException {
		try {
			con = DatabaseConnection.getConnection();
			String sql1 = "select balance from user where accNo=?";
			ps = con.prepareStatement(sql1);
			ps.setLong(1, accountNumber);
			rs = ps.executeQuery();
			if(rs.next()==false)
				throw new AccountExistException("Account Number doesn't exist. Please check the account number");
			Double bal = rs.getDouble("balance");
			if(bal<withdrawAmount)
				throw new InsufficientAmountException("Your account balance is not sufficient.");
			alist.add("Rs. "+withdrawAmount +" withdrawn from account "+accountNumber);
			result = true;
		}
		catch(SQLException e) {
			throw new SQLException("Error Occurred while establishing connection");
		}
		finally {
			if(con!=null) {
				try {
					ps.close();
					con.close();
				}
				catch(SQLException e) {
					throw new SQLException("Your Connection is not properly closed.");
				}
			}
		}
		return result;
	}
	
	public Boolean transfer(Double amount, Long sourceAccNo, Long receiverAccNo) throws AccountExistException,InsufficientAmountException, SQLException {
		try {
			con = DatabaseConnection.getConnection();
			String sql1 = "select balance from user where accNo=?";
			ps = con.prepareStatement(sql1);
			ps.setLong(1, sourceAccNo);
			rs = ps.executeQuery();
			if(rs.next()==false)
				throw new AccountExistException("Source Account Number doesn't exist. Please check the account number");
			Double bal = rs.getDouble("balance");
			if(bal<amount)
				throw new InsufficientAmountException("Your account balance is not sufficient.");
			String sql2 = "update user set balance=balance-? where accNo=?";
			ps = con.prepareStatement(sql2);
			ps.setDouble(1, amount);
			ps.setLong(2, sourceAccNo);
			ps.executeUpdate();
			String sql3 = "update user set balance=balance+? where accNo=?";
			ps= con.prepareStatement(sql3);
			ps.setDouble(1, amount);
			ps.setLong(2, receiverAccNo);
			row = ps.executeUpdate();
			if(row<1)
				throw new AccountExistException("Receiver's Account Number doesn't exist. Please check the account number");
			alist.add("Rs."+amount +" transferred from account "+sourceAccNo+"  to account"+receiverAccNo);
			result = true;
		}
		catch(SQLException e) {
			throw new SQLException("Error Occurred while establishing connection");
		}
		finally {
			if(con!=null) {
				try {
					ps.close();
					con.close();
				}
				catch(SQLException e) {
					throw new SQLException("Your Connection is not properly closed.");
				}
			}
		}
		return result;
	}
	
	public ArrayList<String> getTransactions(Long accNo) throws AccountExistException, SQLException {
		try {
			con = DatabaseConnection.getConnection();
			String sql1 = "select balance from user where accNo=?";
			ps = con.prepareStatement(sql1);
			ps.setLong(1, accNo);
			rs = ps.executeQuery();
			if(rs.next()==false)
				throw new AccountExistException("Source Account Number doesn't exist. Please check the account number");		
			return alist;
		}
		catch(SQLException e) {
			throw new SQLException("Error Occurred while establishing connection");
		}
		finally {
			if(con!=null) {
				try {
					ps.close();
					con.close();
				}
				catch(SQLException e) {
					throw new SQLException("Your Connection is not properly closed.");
				}
			}
		}
	}

}

