package com.capgemini.project.dao;

import java.sql.SQLException;
import java.util.ArrayList;

import com.capgemini.exception.AccountExistException;
import com.capgemini.exception.InsufficientAmountException;
import com.capgemini.project.bean.PaymentWalletBean;

public interface PaymentWalletDaoInterface {

	int accountCreation(PaymentWalletBean bean) throws SQLException;
	Double showBalance(Long ano) throws AccountExistException, SQLException;
	Boolean depositAmt(Double depositAmount, Long accountNumber) throws AccountExistException, SQLException;
	Boolean withdrawAmt(Double withdrawAmount, Long accountNumber) throws AccountExistException, InsufficientAmountException, SQLException;
	Boolean transfer(Double amount, Long sourceAccNo, Long receiverAccNo) throws AccountExistException,InsufficientAmountException, SQLException;
	ArrayList<String> getTransactions(Long accNo) throws AccountExistException, SQLException;
}
