package com.capgemini.project.service;

import java.sql.SQLException;
import java.util.ArrayList;

import com.capgemini.exception.AccountExistException;
import com.capgemini.exception.InsufficientAmountException;
import com.capgemini.exception.InvalidInputDetailException;
import com.capgemini.project.bean.PaymentWalletBean;

public interface PaymentWalletServiceInterface {

	Long createAccount(PaymentWalletBean walletBeanObj) throws InvalidInputDetailException, SQLException;
	Double showBalance(Long accountNumber) throws AccountExistException, SQLException;
	Boolean deposit(Double depositAmount, Long accountNumber) throws AccountExistException, SQLException;
	Boolean withdraw(Double withdrawAmount, Long accountNumber) throws AccountExistException, InsufficientAmountException, SQLException;
	Boolean fundTransfer(Double amount, Long sourceAccNumber, Long receiverAccNumber) throws InsufficientAmountException, AccountExistException, SQLException;
	ArrayList<String> printTransaction(Long accountNumber) throws AccountExistException, SQLException;
}
