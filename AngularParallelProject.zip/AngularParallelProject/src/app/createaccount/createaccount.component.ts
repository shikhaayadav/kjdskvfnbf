import { Component, OnInit } from '@angular/core';
import data from '../../data/details.json'

@Component({
  selector: 'app-createaccount',
  templateUrl: './createaccount.component.html',
  styleUrls: ['./createaccount.component.css']
})
export class CreateaccountComponent implements OnInit {
array=data
accNum: number;
successflag=false
  constructor() { }

  ngOnInit() {
  }

  add(form)
  { 
    this.accNum=(form.phone-12345)*3
    this.array.push({
      accNum: this.accNum, 
      name: form.name, 
      phone: form.phone, 
      email: form.email, 
      balance: 1000})
    this.successflag=true;
  }
}
