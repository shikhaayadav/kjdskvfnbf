import { Component, OnInit } from '@angular/core';
import data from '../../data/details.json'


@Component({
  selector: 'app-showbalance',
  templateUrl: './showbalance.component.html',
  styleUrls: ['./showbalance.component.css']
})
export class ShowbalanceComponent implements OnInit {
array=data
flag=false
  constructor() { }

  ngOnInit() {
  }

  setFlag()
  {
    this.flag=true
  }
}
