import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { CreateaccountComponent } from './createaccount/createaccount.component';
import { ShowbalanceComponent } from './showbalance/showbalance.component';
import { DepositComponent } from './deposit/deposit.component';
import { TransferComponent } from './transfer/transfer.component';
import { WithdrawComponent } from './withdraw/withdraw.component';

const routes: Routes = [
  {
    path: '',
    component: HomeComponent
  },
  {
    path: 'create',
    component: CreateaccountComponent
  },
  {
    path: 'search',
    component: ShowbalanceComponent
  },
  {
    path: 'addmoney',
    component: DepositComponent
  },
  {
    path: 'transfer',
    component: TransferComponent
  },
  {
    path: 'withdraw',
    component: WithdrawComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
