package com.capgemini.exception;

public class AccountExistException extends Exception{
	public AccountExistException(String message) {
		super(message);
	}
}
