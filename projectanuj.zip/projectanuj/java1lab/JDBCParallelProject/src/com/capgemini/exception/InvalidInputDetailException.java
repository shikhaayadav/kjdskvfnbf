package com.capgemini.exception;

@SuppressWarnings("serial")
public class InvalidInputDetailException extends Exception{
	public InvalidInputDetailException(String message) {
		super(message);
	}
}
