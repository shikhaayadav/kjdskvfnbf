package com.capgemini.project.dao;

public interface PaymentWalletDaoInterface {

}
