package com.capgemini.project.service;

import java.util.ArrayList;

import com.capgemini.exception.AccountExistException;
import com.capgemini.exception.InvalidInputDetailException;
import com.capgemini.exception.InsufficientAmountException;
import com.capgemini.project.bean.PaymentWalletBean;
import com.capgemini.project.dao.PaymentWalletDao;

public class PaymentWalletService implements PaymentWalletServiceInterface{
	
	PaymentWalletDao walletDaobj = new PaymentWalletDao();
	Long accNo=null;
	int row=0;

	public Long createAccount(PaymentWalletBean walletBeanObj) throws InvalidInputDetailException{
		if(emailCheck(walletBeanObj.getEmailId()) && numberCheck(walletBeanObj.getMobileNumber()) && nameCheck(walletBeanObj.getName()) && walletBeanObj.getName().length()>=3) {
			accNo = Math.abs((Long.parseLong(walletBeanObj.getMobileNumber())-12341)*13);
			walletBeanObj.setAccountNumber(accNo);
			row=walletDaobj.accountCreation(walletBeanObj);
		} 
		else {
			throw new InvalidInputDetailException("Error Occured!!! Enter valid input");
		}
		if(row>0)
			return accNo;
		else
			return null;
	}
	
	public Double showBalance(Long accountNumber) throws AccountExistException{
		Double balance = walletDaobj.showBalance(accountNumber);;
		return balance;
	}
	
	public Double deposit(Double depositAmount, Long accountNumber) throws AccountExistException{
		Double updatedBal = walletDaobj.depositAmt(depositAmount, accountNumber);
		return updatedBal;
	}
	
	public Double withdraw(Double withdrawAmount, Long accountNumber) throws AccountExistException, InsufficientAmountException {
		Double updatedBal = walletDaobj.withdrawAmt(withdrawAmount, accountNumber);
		return updatedBal;
	}
	
	public Double fundTransfer(Double amount, Long sourceAccNumber, Long receiverAccNumber) throws InsufficientAmountException, AccountExistException{
		Double updatedBal = null;
		updatedBal = walletDaobj.transfer(amount, sourceAccNumber, receiverAccNumber);
		return updatedBal;		
	}
	
	public ArrayList<String> printTransaction(Long accountNumber) throws AccountExistException {
		ArrayList<String> alist = walletDaobj.getTransactions(accountNumber);
		try {
			if(alist!=null)
				return alist;
			else 
				throw new AccountExistException("Account Number doesn't exist. Please check the account number");
		}
		catch(AccountExistException e) {}
		return null;
	}		
	
	boolean nameCheck(String name) {
		boolean result = name.matches("^[a-zA-Z\\s]*$");
		return result;	
	}
	
	boolean emailCheck(String emailId) {
		boolean result = emailId.matches("^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$");
		return result;
	}
	
	boolean numberCheck(String mobile) {
		boolean result = false;
				if(mobile.length()==10 && mobile.charAt(0)!='0')
					result=true;
		return result;
		
	}
	public boolean accNoCheck(String acc) {
		boolean result = false;
//		String accNo = String.valueOf(acc);
//		for(int i=0; i<accNo.length(); i++) {
//			if(accNo.charAt(i)>=(int)48 && accNo.charAt(i)<=(int)57) {
//				result=true;
//				continue;
//			}
//			else {
//				result=false;
//				break;
//			}
//				
//		}
		result = String.valueOf(acc).matches("[0-9]{9,18}");
		return result;
	}
	
}
