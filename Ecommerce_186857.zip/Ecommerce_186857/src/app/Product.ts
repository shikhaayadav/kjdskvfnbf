export class Product {
    id:String;
    name:String;
    price:number
    category:String

}