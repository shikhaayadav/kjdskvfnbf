import { Component, OnInit } from '@angular/core';
import{Service} from '../service.service'

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {

  ProdList:any=[];
  constructor(private proService :  Service) { 
    this.proService.getproDetails().subscribe(data => this.ProdList = data);
  this.ProdList= this.proService.ProdList;
   
  }
  
  ngOnInit() {
    this.ProdList= this.proService.ProdList;
    
  }
  delete(id:String){
    this.proService.deletepro(id);
    this.ProdList= this.proService.ProdList;
  }
}
