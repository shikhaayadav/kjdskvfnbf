import { Product } from './Product';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class Service {
pro:Product;

  constructor(private httpClient:HttpClient) { 
 
  this.getproDetails().subscribe(data => this.ProdList = data);}

ProdList: Array<Product> = [];

url: string = "/assets/db.json";
getproDetails(): any {
  return this.httpClient.get<Product>(this.url);
}


setmovieDetails(pro: Product) {
  this.ProdList.push(pro);

}
myArray: Array<Product>;


search(data):any[]
{

  this.myArray=[];
for(let pro of this.ProdList)
{


  if(pro.name==data.name || pro.category==data.name)
  {
    this.myArray.push(pro);
  }
}

return (this.myArray)
}



deletepro(id: String): void {
  let i = 0;
  for (let pro of this.ProdList) {
    if (pro.id == id) {
      console.log("Product id " + pro.id);
      console.log(this.ProdList.splice(i, 1));
    }
    i++;
  }

}
}