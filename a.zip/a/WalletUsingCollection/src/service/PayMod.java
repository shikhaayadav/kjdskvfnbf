package service;

import java.util.Scanner;
import java.util.regex.Pattern;

public class PayMod {
	Scanner sc=new Scanner(System.in);
	public float aCheck(float amount) {
		while(true) {
			if(amount<=0) {
				System.out.println("Amount should be greater than 0.");
				System.out.println("Enter again: ");
				amount = sc.nextInt();
			}
			else {
				return amount;
			}
		}
	}

	public String Check(String name) {
		while(true) {
			if(Pattern.matches("([A-Z])*([a-z])*", name)){
				return name;
			}
			else {
				System.out.println("Name should only have alphabets.");
				System.out.println("Enter again: ");
				name = sc.next();
			}
		}
	}

//		METHOD TO CHECK THE LENGTH OF MOBILE NUMBER
	public long mobCheck(long mob) { 
		while(true) {
			if(String.valueOf(mob).length() < 10) {
				System.out.println("Enter valid mobile number.");
				mob = sc.nextLong();
			}
			else {
				return mob;
			}
		}
	}

}
